﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TitanInformationSolutions.Data.Migrations
{
    public partial class pwapush : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Subs_Parent_ParentID",
                table: "Subs");

            migrationBuilder.RenameColumn(
                name: "ParentID",
                table: "Subs",
                newName: "InstructorID");

            migrationBuilder.RenameIndex(
                name: "IX_Subs_ParentID",
                table: "Subs",
                newName: "IX_Subs_InstructorID");

            migrationBuilder.AddForeignKey(
                name: "FK_Subs_Instructor_InstructorID",
                table: "Subs",
                column: "InstructorID",
                principalTable: "Instructor",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Subs_Instructor_InstructorID",
                table: "Subs");

            migrationBuilder.RenameColumn(
                name: "InstructorID",
                table: "Subs",
                newName: "ParentID");

            migrationBuilder.RenameIndex(
                name: "IX_Subs_InstructorID",
                table: "Subs",
                newName: "IX_Subs_ParentID");

            migrationBuilder.AddForeignKey(
                name: "FK_Subs_Parent_ParentID",
                table: "Subs",
                column: "ParentID",
                principalTable: "Parent",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
